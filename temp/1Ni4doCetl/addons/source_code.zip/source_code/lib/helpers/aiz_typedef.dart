typedef OnPress = void Function();
typedef GetStringArray = Function(List list);
typedef GetString = Function(dynamic value);
