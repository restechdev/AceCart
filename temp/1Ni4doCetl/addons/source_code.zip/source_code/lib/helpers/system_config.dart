import 'package:active_ecommerce_seller_app/data_model/login_response.dart';

class SystemConfig {
  static User? systemUser;
}
