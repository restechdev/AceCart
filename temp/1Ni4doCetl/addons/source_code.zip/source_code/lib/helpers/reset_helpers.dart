import 'package:active_ecommerce_seller_app/helpers/shared_value_helper.dart';

class ResetHelper{

  clean(){
  // seller_package_addon.save();
  // refund_addon.$= false;
  // refund_addon.save();
  // conversation_activation.$= false;
  // conversation_activation.save();
  // coupon_activation.$= false;
  // coupon_activation.save();
  // offline_payment_addon.$= false;
  // offline_payment_addon.save();
  // seller_product_manage_admin.$= false;
  // seller_product_manage_admin.save();

  }

}