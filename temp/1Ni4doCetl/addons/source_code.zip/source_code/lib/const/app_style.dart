import 'package:flutter/cupertino.dart';

class AppStyles{
static  double layoutMargin = 16;
static double listItemsMargin=16;
static double itemMargin=16;

static FontWeight normal = FontWeight.normal;
static FontWeight medium = FontWeight.w500;
static FontWeight bold = FontWeight.bold;
static FontWeight extraBold = FontWeight.w800;
static FontWeight light = FontWeight.w400;
static FontWeight extraLight = FontWeight.w300;

}