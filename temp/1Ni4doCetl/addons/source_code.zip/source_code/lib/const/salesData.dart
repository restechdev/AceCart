class SalesData {
  SalesData(this.year, this.sales);
  final int year;
  final int sales;
}