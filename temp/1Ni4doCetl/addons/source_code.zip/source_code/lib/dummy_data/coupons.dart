class ListCoupons{
  String? title,subTitle,exp;

  ListCoupons({this.title, this.subTitle, this.exp});
 List<ListCoupons> getList(){
    List<ListCoupons> list =[];
    
    list.add(ListCoupons(title: "MAS150",subTitle: "Cart Base Cart Base",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150",subTitle: "Cart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150MAS150MAS150",subTitle: "Cart Base	Cart BaseCart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150",subTitle: "Cart Base Cart Base",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150",subTitle: "Cart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150MAS150MAS150",subTitle: "Cart Base	Cart BaseCart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150",subTitle: "Cart Base Cart Base",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150",subTitle: "Cart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150MAS150MAS150",subTitle: "Cart Base	Cart BaseCart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150",subTitle: "Cart Base Cart Base",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150",subTitle: "Cart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150MAS150MAS150",subTitle: "Cart Base	Cart BaseCart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150",subTitle: "Cart Base Cart Base",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150",subTitle: "Cart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150MAS150MAS150",subTitle: "Cart Base	Cart BaseCart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150",subTitle: "Cart Base Cart Base",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150",subTitle: "Cart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150MAS150MAS150",subTitle: "Cart Base	Cart BaseCart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150",subTitle: "Cart Base Cart Base",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150",subTitle: "Cart Base	",exp: "07-02-2022   to   30-06-2022"));
    list.add(ListCoupons(title: "MAS150MAS150MAS150MAS150",subTitle: "Cart Base	Cart BaseCart Base	",exp: "07-02-2022   to   30-06-2022"));
return list;
  }
  
}