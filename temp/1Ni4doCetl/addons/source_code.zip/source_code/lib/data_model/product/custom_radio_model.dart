

class CustomRadioModel{
  String title,key;
  bool isActive;

  CustomRadioModel(this.title,this.key, this.isActive);
}
