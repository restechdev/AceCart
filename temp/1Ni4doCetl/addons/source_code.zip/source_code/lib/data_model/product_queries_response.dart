// To parse this JSON data, do
//
//     final productQueriesResponse = productQueriesResponseFromJson(jsonString);

import 'dart:convert';

ProductQueriesResponse productQueriesResponseFromJson(String str) =>
    ProductQueriesResponse.fromJson(json.decode(str));

String productQueriesResponseToJson(ProductQueriesResponse data) =>
    json.encode(data.toJson());

class ProductQueriesResponse {
  List<ProductQueriesListModel>? data;
  Links? links;
  Meta? meta;

  ProductQueriesResponse({
    this.data,
    this.links,
    this.meta,
  });

  factory ProductQueriesResponse.fromJson(Map<String, dynamic> json) =>
      ProductQueriesResponse(
        data: json["data"] == null
            ? []
            : List<ProductQueriesListModel>.from(
                json["data"]!.map((x) => ProductQueriesListModel.fromJson(x))),
        links: json["links"] == null ? null : Links.fromJson(json["links"]),
        meta: json["meta"] == null ? null : Meta.fromJson(json["meta"]),
      );

  Map<String, dynamic> toJson() => {
        "data": data == null
            ? []
            : List<dynamic>.from(data!.map((x) => x.toJson())),
        "links": links?.toJson(),
        "meta": meta?.toJson(),
      };
}

class ProductQueriesListModel {
  int? id;
  String? userName;
  String? userImage;
  String? question;
  String? reply;
  String? product;
  String? status;
  String? createdAt;

  ProductQueriesListModel({
    this.id,
    this.userName,
    this.userImage,
    this.question,
    this.reply,
    this.product,
    this.status,
    this.createdAt,
  });

  factory ProductQueriesListModel.fromJson(Map<String, dynamic> json) =>
      ProductQueriesListModel(
        id: json["id"],
        userName: json["user_name"],
        userImage: json["user_image"],
        question: json["question"],
        reply: json["reply"],
        product: json["product"],
        status: json["status"],
        createdAt: json["created_at"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_name": userName,
        "user_image": userImage,
        "question": question,
        "reply": reply,
        "product": product,
        "status": status,
        "created_at": createdAt,
      };
}

class Links {
  String? first;
  String? last;
  dynamic prev;
  dynamic next;

  Links({
    this.first,
    this.last,
    this.prev,
    this.next,
  });

  factory Links.fromJson(Map<String, dynamic> json) => Links(
        first: json["first"],
        last: json["last"],
        prev: json["prev"],
        next: json["next"],
      );

  Map<String, dynamic> toJson() => {
        "first": first,
        "last": last,
        "prev": prev,
        "next": next,
      };
}

class Meta {
  int? currentPage;
  int? from;
  int? lastPage;
  List<Link>? links;
  String? path;
  int? perPage;
  int? to;
  int? total;

  Meta({
    this.currentPage,
    this.from,
    this.lastPage,
    this.links,
    this.path,
    this.perPage,
    this.to,
    this.total,
  });

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        currentPage: json["current_page"],
        from: json["from"],
        lastPage: json["last_page"],
        links: json["links"] == null
            ? []
            : List<Link>.from(json["links"]!.map((x) => Link.fromJson(x))),
        path: json["path"],
        perPage: json["per_page"],
        to: json["to"],
        total: json["total"],
      );

  Map<String, dynamic> toJson() => {
        "current_page": currentPage,
        "from": from,
        "last_page": lastPage,
        "links": links == null
            ? []
            : List<dynamic>.from(links!.map((x) => x.toJson())),
        "path": path,
        "per_page": perPage,
        "to": to,
        "total": total,
      };
}

class Link {
  String? url;
  String? label;
  bool? active;

  Link({
    this.url,
    this.label,
    this.active,
  });

  factory Link.fromJson(Map<String, dynamic> json) => Link(
        url: json["url"],
        label: json["label"],
        active: json["active"],
      );

  Map<String, dynamic> toJson() => {
        "url": url,
        "label": label,
        "active": active,
      };
}
