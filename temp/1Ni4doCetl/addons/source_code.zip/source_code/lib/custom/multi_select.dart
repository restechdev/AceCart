class SelectProduct {
  SelectProduct({this.id, this.name, this.isSelect});
  var id;
  String? name;
  bool? isSelect;
}
