typedef futureVoid = Future<void> Function();
