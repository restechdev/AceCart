package com.activeitzone.active_ecommerce_seller_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
