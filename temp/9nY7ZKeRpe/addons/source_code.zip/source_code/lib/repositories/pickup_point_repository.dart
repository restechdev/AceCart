


class PickupPointRepository{

}