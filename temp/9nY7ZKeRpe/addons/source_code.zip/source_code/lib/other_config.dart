class OtherConfig {
  static const bool USE_PUSH_NOTIFICATION = true;
  static const bool USE_GOOGLE_MAP = true;
  static const String GOOGLE_MAP_API_KEY = "";
}
